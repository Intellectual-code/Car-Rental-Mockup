import React from 'react'
import "./footer.css"
export default function Footer() {
  return (
    <footer>
      <div className='about-f'>
        <div className='logo'>
          <img src='./images/car(3) 1.png' />
          <p>Car Rental</p>
        </div>

        <div className='about-d'>
          <img src='./images/Icon+bg (2).png' />
          <span><p>Email</p>
            <p>nwiger@yahoo.com</p></span>

        </div>
        <div className='about-d'>
          <img src='./images/Icon+bg (3).png' />
          <span><p>Phone</p>
            <p>+537 547-6401</p></span>
        </div>
        <div className='about-d'>
          <img src='./images/Icon+bg (4).png' />
          <span><p>Opening hours</p>
            <p>Sun-Mon: 10am - 10pm</p></span>

        </div>
      </div>

        <div className='footer-tr'>
          <span className='footer-p'>
            <p>Faucibus faucibus pellentesque dictum turpis. Id pellentesque turpis massa a id iaculis lorem t...</p>
            <img src='./images/Social icons.png'/>
          </span>
          <span className='footer-c1'>
            <h3>Useful links</h3>
            <ul>
              <li>About us</li>
              <li>Contact us</li>
              <li>Gallery</li>
              <li>Blog</li>
              <li>F.A.Q</li>
            </ul>
          </span>
          <span className='footer-c1'>
            <h3>Vehicles</h3>
            <ul>
              <li>Sedan</li>
              <li>Cabriolet</li>
              <li>Pickup</li>
              <li>Minivan</li>
              <li>SUV</li>
            </ul>
          </span>
          <span className='footer-c1'> 
            <h3>Download App</h3>
            <p><img src="./images/Google Play.png" /></p>
            <p><img src="./images/App Store.png" /></p>
          </span>
        </div>

      <p className='c'>© Copyright Car Rental 2024. Design by Figma.guru</p>

    </footer>
  )
}
