import React from 'react'
import "./header.css"
export default function Header() {
  return (
    <header>
        <div className='logo'>
            <img src='./images/car(3) 1.png'/>
            <p>Car Rental</p>
        </div>
        <div className='nav'>
            <a>Home</a>
            <a>Vehicles</a>
            <a>Details</a>
            <a>About Us</a>
            <a>Contact Us</a>
        </div>
        <div className='contact'>
            <img src='./images/Icon+bg.png' />
            <span>
                <p>Need help?</p>
                <p>+996 247-1680</p>
            </span>
        </div>
    </header>
  )
}
