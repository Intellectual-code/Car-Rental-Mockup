import React from 'react'
import "./main.css"
export default function Main() {
  return (
    <div className='main'>
        <div className='bread'>
            <span>
            <p className='con1'>Contact Us</p>
            <p className='con2'>Home / Contact Us</p>
            </span>
        </div>
        <div className='box'>
            <div className='lbox'>
                <div className='box-card'>
                    <h1>Book your car</h1>
                    <input placeholder='Car type' />
                    <input placeholder='Place of rental'/>
                    <input placeholder='Place of return'/>
                    <input placeholder='Rental date'/>
                    <input placeholder='Return date'/>
                    <button className='box-btn'>Book now</button>
                </div>
            </div>
            <div className='rbox'>
                <img src='./images/Img.jpg'/>
            </div>
        </div>
        <div className='about'>
            <div className='about-d'>
                <img src='./images/Icon+bg (1).png' />
                <span>
                    <p>Address</p>
                    <p>Oxford Ave. Cary, NC 27511</p>
                </span>
            </div>
            <div className='about-d'>
                <img src='./images/Icon+bg (2).png'/>
                <span><p>Email</p>
                    <p>nwiger@yahoo.com</p></span>
                
            </div>
            <div className='about-d'>
                <img src='./images/Icon+bg (3).png'/>
                <span><p>Phone</p>
                    <p>+537 547-6401</p></span>
            </div>
            <div className='about-d'>
                <img src='./images/Icon+bg (4).png'/>
                <span><p>Opening hours</p>
                    <p>Sun-Mon: 10am - 10pm</p></span>
                
            </div>
        </div>
        <div className='videos'>

            <div className='vid-title'>Latest blog posts & news</div>
            <div>
                <div className='vid-card'>
                    <img src='./images/Img.png' />
                    <h3>How to choose the right car</h3>
                    <p>News / 12April 2024</p>
                </div>
                <div className='vid-card'>
                    <img src='./images/Img (1).png' />
                    <h3>How to choose the right car</h3>
                    <p>News / 12April 2024</p>
                </div>
                <div className='vid-card'>
                    <img src='./images/Img (2).png' />
                    <h3>How to choose the right car</h3>
                    <p>News / 12April 2024</p>
                </div>
            </div>
        </div>
        <div className='logos'>
            <div className='logo-box'>
                <img src='./images/layer1.png'/>
                <img src='./images/Logo (2).png'/>
                <img src='./images/Logo (3).png'/>
                <img src='./images/Logo (4).png'/>
                <img src='./images/Vector (1).png'/>
                <img src='./images/Vector (2).png'/>
            </div>
        </div>
    </div>
  )
}
